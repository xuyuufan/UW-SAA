Complete GP-only Caserta MAIN results: 68,880 formal endpoints, 41 conditions, 840 layouts, two arms.
local/ owns conditions 1-14 (23,520 rows); cloud/ owns 15-41 (45,360 rows).
Probe endpoints under integrity/probe_diagnostic_only/ are diagnostic and excluded from formal totals.
Primary effect is the equal mean of SS/TW/DP family-relative reductions. This is not MEAN6 or an all-six-solver result.
See analysis/结果说明.md for the full report. Independent scientific review is pending.
