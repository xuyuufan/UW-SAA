"""Verify the uploaded local archive and analyze the complete frozen GP matrix."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

ROOT = Path('/workspace/work/gp-pr9')
WORK = Path('/workspace/work/gp-analysis')
LOCAL = Path('/workspace/work/gp-local-20261024')
CLOUD = ROOT / 'reproducibility/results/gp_caserta_cloud_15_41_20261024T114249Z'
ARCHIVE = Path('/workspace/attachments/027dca6d-f5c2-4861-8560-ed86dd028d5d/gp_caserta_local_conditions_01_14_20261024.zip')
OUTPUT = Path('/codex/browser/projectless/0002-repo-pr-gp-caserta/output/gp-caserta-complete')
sys.path.insert(0, str(ROOT))
from reproducibility import gp_arm_paired_analysis as analysis
from reproducibility.gp_caserta_partition_runner import validate_saved, runtime_inventory

def sha(data):
    return hashlib.sha256(data).hexdigest()

archive_sha = analysis.sha_file(ARCHIVE)
LOCAL.mkdir(exist_ok=False)
with zipfile.ZipFile(ARCHIVE) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 30, 'unexpected archive members'
    for info in z.infolist():
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and len(p.parts) == 1 and p.name not in ('.', '..')
        assert not stat.S_ISLNK(info.external_attr >> 16)
    sums = {}
    for line in z.read('SHA256SUMS.txt').decode('utf-8-sig').splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, f'invalid checksum record: {line}'
        value, name = match.groups()
        assert name not in sums
        sums[name] = value
    assert set(names) == set(sums) | {'SHA256SUMS.txt'}
    for name in names:
        payload = z.read(name)
        if name != 'SHA256SUMS.txt':
            assert sha(payload) == sums[name], f'archive checksum mismatch: {name}'
        (LOCAL / name).write_bytes(payload)

local = json.loads((LOCAL / 'run_manifest.json').read_text())
cloud = json.loads((CLOUD / 'run_manifest.json').read_text())
registry = list(analysis.condition_registry().values())
data = ROOT / 'data/caserta_table2_840.json'
gp = analysis.active_gp_record(json.loads((ROOT / 'configs/gp_rule.json').read_text()))
inventory = runtime_inventory()
for manifest, indexes, expected_rows, directory in (
        (local, list(range(1, 15)), 23520, LOCAL),
        (cloud, list(range(15, 42)), 45360, CLOUD)):
    assert manifest['status'] == 'complete' and not manifest['failures'] and not manifest['active_children']
    assert manifest['condition_indexes'] == indexes
    assert manifest['expected_endpoint_rows'] == manifest['completed_endpoint_rows'] == expected_rows
    assert manifest['conditions'] == [registry[i-1] for i in indexes]
    assert manifest['gp_model'] == gp
    assert manifest['dataset_sha256'] == analysis.sha_file(data)
    assert manifest['runtime_inventory'] == inventory
    assert manifest['partition_runner_sha256'] == analysis.sha_file(ROOT / 'reproducibility/gp_caserta_partition_runner.py')
    assert manifest['validation_script_sha256'] == analysis.sha_file(ROOT / 'reproducibility/gp_arm_paired_analysis.py')
    assert validate_saved(directory, manifest, data, manifest['dataset_sha256'], gp) == set(indexes)
assert not set(local['condition_indexes']) & set(cloud['condition_indexes'])
assert set(local['condition_indexes']) | set(cloud['condition_indexes']) == set(range(1, 42))
endpoints = [LOCAL / f'condition-{i:02d}.jsonl' for i in range(1, 15)]
endpoints += [CLOUD / f'condition-{i:02d}.jsonl' for i in range(15, 42)]
manifest = analysis.execute(argparse.Namespace(endpoint=endpoints, data=data,
                                              rule=ROOT / 'configs/gp_rule.json', output_dir=OUTPUT))
assert manifest['observed_endpoint_rows'] == 68880
receipt = {'status': 'pass', 'local_zip_sha256': archive_sha, 'archive_files_checked': len(sums),
           'local_rows': 23520, 'cloud_rows': 45360, 'combined_rows': 68880,
           'conditions': 41, 'layouts': 840, 'geometries': 21, 'paired_cells': 34440,
           'missing_or_duplicate_or_failed_endpoints': 0,
           'model_dataset_and_runtime_match': True,
           'local_manifest_sha256': analysis.sha_file(LOCAL / 'run_manifest.json'),
           'cloud_manifest_sha256': analysis.sha_file(CLOUD / 'run_manifest.json'),
           'analysis_manifest_sha256': analysis.sha_file(OUTPUT / 'analysis_manifest.json'),
           'scope': 'Full GP-only MAIN matrix. Statistics pending independent review; no six-solver result.'}
(OUTPUT / 'merge_integrity.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
